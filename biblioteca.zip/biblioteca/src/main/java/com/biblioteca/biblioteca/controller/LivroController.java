
package com.biblioteca.biblioteca.controller;

import java.util.List;
import java.util.ArrayList;

import com.biblioteca.biblioteca.Repository.LivroRepository;
import org.springframework.web.bind.annotation.PathVariable;
import com.biblioteca.biblioteca.Model.Livro;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Livros")

public class LivroController {

    private final LivroRepository repository;

    public LivroController(LivroRepository repository){
        this.repository = repository;
    }

    @GetMapping("/novo")
    public String novoLivro(Model model) {
        model.addAttribute("livro", new Livro());
        return "Livros/form";
    }

    @PostMapping
    public String cadastrarLivro(@ModelAttribute Livro livro) {
        repository.save(livro);
        return "redirect:/Livros";
    }

    @GetMapping
    public String listar(Model model) {
        List<Livro> livros = repository.findAll();
        model.addAttribute("livros", livros);
        return "Livros/lista";
    }

    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id) {
        repository.deleteById(id);
        return "redirect:/Livros";
    }

    @GetMapping("/Livro")
    public String exibirLivro(Model model) {
        Livro livro = new Livro();
        livro.setTitulo("JoJo's Bizarre Adventure");
        livro.setAutor("Hirohiko Araki");
        livro.setISBN("978-85-00-00000-0");

        model.addAttribute("Livro", livro);
        return "livro";
    }
}