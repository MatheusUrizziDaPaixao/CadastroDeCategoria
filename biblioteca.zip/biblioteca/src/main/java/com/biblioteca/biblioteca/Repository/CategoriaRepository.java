package com.biblioteca.biblioteca.Repository;

import com.biblioteca.biblioteca.Model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
}